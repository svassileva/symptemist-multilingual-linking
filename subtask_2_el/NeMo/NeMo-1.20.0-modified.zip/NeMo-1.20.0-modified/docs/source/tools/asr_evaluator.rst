ASR Evaluator
========================

ASR evaluator is a tool for thoroughly evaluating the performance of ASR models and other features such as Voice Activity Detection.

See more details in: https://github.com/NVIDIA/NeMo/tree/stable/tools/asr_evaluator