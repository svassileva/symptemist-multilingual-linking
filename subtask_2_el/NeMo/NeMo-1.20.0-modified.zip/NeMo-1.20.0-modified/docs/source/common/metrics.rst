Metrics
-------

.. autoclass:: nemo.collections.common.metrics.Perplexity
    :show-inheritance:
    :members:
    :undoc-members:
