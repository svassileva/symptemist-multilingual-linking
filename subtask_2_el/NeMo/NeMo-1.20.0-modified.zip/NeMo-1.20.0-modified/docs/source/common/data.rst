Data
----

.. autoclass:: nemo.collections.common.data.dataset.ConcatDataset
    :show-inheritance:
    :members:
    :undoc-members:


.. autoclass:: nemo.collections.common.data.dataset.ConcatMapDataset
    :show-inheritance:
    :members:
    :undoc-members:
